import React from 'react'

const ThirdSection = () => {
  return (
    <>
    <div class="row">
        <div class="col">1 of 2</div>
        <div class="col">2 of 2</div>
    </div>
    </>
  )
}

export default ThirdSection